import React from 'react';
export default class Profile extends React.Component{
    render(){
        return <div>profile</div>
    }
}