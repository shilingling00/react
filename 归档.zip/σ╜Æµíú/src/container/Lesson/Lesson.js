import React from 'react';
export default class Lesson extends React.Component{
    render(){
        return <div>lesson</div>
    }
}