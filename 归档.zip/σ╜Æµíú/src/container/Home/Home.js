import React from 'react';
export default class Home extends React.Component{
    render(){
        return <div className='homes'>home</div>
    }
}