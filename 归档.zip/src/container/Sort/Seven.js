import React from 'react';
export default class Seven extends React.Component{
    render(){
        return <div>
            seven
        </div>
    }
}