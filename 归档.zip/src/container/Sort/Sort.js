import React from 'react';
import './index.css';
import Teaching from './Teaching'
export default class Sort extends React.Component{
    render(){
        return <div className='sort'>
            {/*<p>1+1=
                <input type="text"/>
            </p>*/}
            <Teaching/>
        </div>
    }
}