import React from 'react';
import {NavLink, Route} from "react-router-dom";
import Seven from "./Seven";

export  default class Teaching extends React.Component{
    render(){
        return <div className="teach">
            <NavLink to={'./sort/seven'} exact={true}>七年级</NavLink>
            <div>
                <Route path='/sort/seven'  component={Seven}/>
            </div>
        </div>
    }
}