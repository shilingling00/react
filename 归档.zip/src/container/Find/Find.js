import React from 'react';
export default class Find extends React.Component{
    render(){
        return <div>Find</div>
    }
}